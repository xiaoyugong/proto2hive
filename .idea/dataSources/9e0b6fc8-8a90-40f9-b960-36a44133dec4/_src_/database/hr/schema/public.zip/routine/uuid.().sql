create function uuid() returns character varying
LANGUAGE plpgsql
AS $$
BEGIN
	-- Routine body goes here...
	RETURN REPLACE
	( gen_random_uuid() :: VARCHAR, '-' ::VARCHAR, '' :: VARCHAR );
END
$$;
